const Ticket = require('../models/ticketModel');
const Buyer = require('../models/buyerModel');
const Seat = require('../models/seatModel');

const ticketController = {
  // Get all sold tickets (replaces getAllStudents)
  getAllTickets: async (req, res) => {
    try {
      const tickets = await Ticket.getAll();
      res.json({
        success: true,
        data: tickets
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error fetching tickets',
        error: error.message
      });
    }
  },

  // Get ticket by ID (replaces getStudentById)
  getTicketById: async (req, res) => {
    try {
      const ticket = await Ticket.getById(req.params.id);
      if (!ticket) {
        return res.status(404).json({
          success: false,
          message: 'Ticket not found'
        });
      }
      res.json({
        success: true,
        data: ticket
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error fetching ticket',
        error: error.message
      });
    }
  },

  // Create new ticket (Record a sale - replaces createStudent)
  createTicket: async (req, res) => {
    try {
      // Required fields for a new sale transaction
      const { BuyerID, SeatID, paymentMethod, FinalSalePrice } = req.body;

      // 1. Validation for required fields
      if (!BuyerID || !SeatID || !paymentMethod || !FinalSalePrice) {
        return res.status(400).json({
          success: false,
          message: 'Required fields (BuyerID, SeatID, paymentMethod, FinalSalePrice) are missing.'
        });
      }

      // 2. Pre-check: Ensure the Buyer and Seat exist (Optional, but highly recommended)
      const buyerExists = await Buyer.getById(BuyerID);
      const seatExists = await Seat.getById(SeatID);

      if (!buyerExists) {
        return res.status(400).json({ success: false, message: 'Invalid BuyerID.' });
      }
      if (!seatExists) {
        return res.status(400).json({ success: false, message: 'Invalid SeatID.' });
      }
      
      // 3. Pre-check: Ensure the seat has NOT been sold yet (availability check)
      const ticketExists = await Ticket.getBySeatId(SeatID); // Assuming a model method exists
      if (ticketExists) {
        return res.status(409).json({ success: false, message: 'Seat already sold.' });
      }
      
      // 4. Create the new ticket record (the sale)
      const newTicket = await Ticket.create({
        BuyerID,
        SeatID,
        date: new Date(), // Set the current date/time
        paymentMethod,
        FinalSalePrice,
        status: 'Valid' 
      });

      res.status(201).json({
        success: true,
        message: 'Ticket purchased successfully',
        data: newTicket
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error creating ticket (sale failed)',
        error: error.message
      });
    }
  },

  // Update ticket status (e.g., Cancellation or Refund - replaces updateStudent)
  updateTicket: async (req, res) => {
    try {
      const { status } = req.body;
      const ticketId = req.params.id;

      // Check if ticket exists
      const existingTicket = await Ticket.getById(ticketId);
      if (!existingTicket) {
        return res.status(404).json({
          success: false,
          message: 'Ticket not found'
        });
      }

      // Validation
      if (!status) {
        return res.status(400).json({
          success: false,
          message: 'Status field is required for update'
        });
      }
      
      // Allow only status updates (e.g., 'Canceled', 'Used')
      await Ticket.update(ticketId, { status });

      res.json({
        success: true,
        message: 'Ticket status updated successfully'
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error updating ticket status',
        error: error.message
      });
    }
  },

  // Delete ticket (Not recommended for sales systems, replaced with CANCELLATION logic)
  // For auditing, we generally update status to 'Canceled' instead of deleting.
  deleteTicket: (req, res) => {
    return res.status(405).json({
      success: false,
      message: 'Method Not Allowed. Tickets should be CANCELED, not deleted, for audit purposes.'
    });
  },

  // Get tickets by status (e.g., 'Valid', 'Canceled', 'Used' - replaces getStudentsByStatus)
  getTicketsByStatus: async (req, res) => {
    try {
      const { status } = req.params;
      const tickets = await Ticket.getByStatus(status);
      
      res.json({
        success: true,
        data: tickets
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error fetching tickets by status',
        error: error.message
      });
    }
  }
};

module.exports = ticketController;