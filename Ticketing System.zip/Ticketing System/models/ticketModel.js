const db = require('../database');

const Ticket = {
  // Get all sold tickets
  getAll: () => {
    return new Promise((resolve, reject) => {
      // Joins Ticket, Buyer, and Seat to get full context for sold tickets
      const sql = `
        SELECT
          T.TicketID, T.date, T.FinalSalePrice, T.status, T.paymentMethod,
          B.name AS BuyerName, B.Email AS BuyerEmail,
          S.label AS SeatLabel, S.section AS SeatSection
        FROM Ticket T
        JOIN Buyer B ON T.BuyerID = B.BuyerID
        JOIN Seat S ON T.SeatID = S.SeatID
      `;
      db.query(sql, (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  },

  // Get ticket by ID
  getById: (id) => {
    return new Promise((resolve, reject) => {
      const sql = `
        SELECT
          T.*,
          B.name AS BuyerName,
          S.label AS SeatLabel
        FROM Ticket T
        JOIN Buyer B ON T.BuyerID = B.BuyerID
        JOIN Seat S ON T.SeatID = S.SeatID
        WHERE T.TicketID = ?`;
      db.query(sql, [id], (err, results) => {
        if (err) reject(err);
        // The query returns an array; we expect the first element
        resolve(results[0]); 
      });
    });
  },

  // Check if a seat is already claimed (crucial for availability)
  getBySeatId: (seatId) => {
    return new Promise((resolve, reject) => {
      // Find a ticket using the specific SeatID
      db.query('SELECT * FROM Ticket WHERE SeatID = ?', [seatId], (err, results) => {
        if (err) reject(err);
        // Returns the ticket record if sold, otherwise undefined
        resolve(results[0]); 
      });
    });
  },

  // Create new ticket (Record a sale)
  create: (ticketData) => {
    return new Promise((resolve, reject) => {
      const { BuyerID, SeatID, date, paymentMethod, FinalSalePrice, status } = ticketData;
      
      const sql = `
        INSERT INTO Ticket (BuyerID, SeatID, date, paymentMethod, FinalSalePrice, status)
        VALUES (?, ?, ?, ?, ?, ?)
      `;
      db.query(
        sql,
        [BuyerID, SeatID, date, paymentMethod, FinalSalePrice, status],
        (err, results) => {
          if (err) reject(err);
          // Return the full ticket data including the new primary key
          resolve({ TicketID: results.insertId, ...ticketData }); 
        }
      );
    });
  },

  // Update ticket (Only status is typically updated in a sales record)
  update: (id, updateData) => {
    return new Promise((resolve, reject) => {
      const { status } = updateData; 
      
      const sql = 'UPDATE Ticket SET status = ? WHERE TicketID = ?';
      db.query(
        sql,
        [status, id],
        (err, results) => {
          if (err) reject(err);
          resolve(results);
        }
      );
    });
  },

  // Delete ticket (Kept the method but advised against its use in the controller)
  delete: (id) => {
    return new Promise((resolve, reject) => {
      db.query('DELETE FROM Ticket WHERE TicketID = ?', [id], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  },

  // Get tickets by status (e.g., 'Valid', 'Canceled', 'Used')
  getByStatus: (status) => {
    return new Promise((resolve, reject) => {
      db.query('SELECT * FROM Ticket WHERE status = ?', [status], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }
};

module.exports = Ticket;