// models/seatModel.js

const db = require('../database'); 

const Seat = {
  // Get seat by ID (required by ticketController for validation)
  getById: (id) => {
    return new Promise((resolve, reject) => {
      db.query('SELECT * FROM Seat WHERE SeatID = ?', [id], (err, results) => {
        if (err) reject(err);
        resolve(results[0]); 
      });
    });
  },

  // You would add getAllSeats, getAvailableSeats (via JOIN/LEFT JOIN) here later
};

module.exports = Seat;