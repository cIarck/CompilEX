// models/buyerModel.js

const db = require('../database'); // Correct path based on your structure (../db.js is in root)

const Buyer = {
  // Get buyer by ID (required by ticketController for validation)
  getById: (id) => {
    return new Promise((resolve, reject) => {
      // NOTE: We use 'Buyer' as the table name based on our SQL schema
      db.query('SELECT * FROM Buyer WHERE BuyerID = ?', [id], (err, results) => {
        if (err) reject(err);
        // Returns the buyer object if found, otherwise undefined/null
        resolve(results[0]); 
      });
    });
  },

  // You would add other methods (getAll, create, update, delete) here later
  
  // Placeholder method for getting all buyers
  getAll: () => {
    return new Promise((resolve, reject) => {
        db.query('SELECT * FROM Buyer', (err, results) => {
            if (err) reject(err);
            resolve(results);
        });
    });
  },
};

module.exports = Buyer;