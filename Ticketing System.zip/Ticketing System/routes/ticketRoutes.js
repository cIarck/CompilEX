const express = require('express');
const router = express.Router();
const ticketController = require('../controllers/ticketController');

// GET /api/tickets - Get all sold tickets
router.get('/', ticketController.getAllTickets);

// GET /api/tickets/status/:status - Get tickets by status (e.g., /api/tickets/status/Canceled)
router.get('/status/:status', ticketController.getTicketsByStatus);

// GET /api/tickets/:id - Get ticket by ID
router.get('/:id', ticketController.getTicketById);

// POST /api/tickets - Create new ticket (Record a sale)
router.post('/', ticketController.createTicket);

// PUT /api/tickets/:id - Update ticket status (e.g., change status to 'Canceled')
router.put('/:id', ticketController.updateTicket);

// DELETE /api/tickets/:id - Delete ticket (Use with caution; cancellation is preferred)
router.delete('/:id', ticketController.deleteTicket);

module.exports = router;